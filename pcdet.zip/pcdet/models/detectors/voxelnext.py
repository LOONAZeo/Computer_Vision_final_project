from .detector3d_template import Detector3DTemplate
import time
import torch
import torch.nn as nn

from ...data_utils import isin, istopk
criterion = torch.nn.BCEWithLogitsLoss()

from ...utils import common_utils
import numpy as np

class MAELoss(nn.Module):
    def __init__(self):
        super(MAELoss, self).__init__()

    def forward(self, inputs, target):
        return torch.mean(torch.abs(inputs - target))

class VoxelNeXt(Detector3DTemplate):
    def __init__(self, model_cfg, num_class, dataset):
        super().__init__(model_cfg=model_cfg, num_class=num_class, dataset=dataset)
        self.module_list = self.build_networks()
        self.mse = torch.nn.MSELoss()
        self.mae_loss = MAELoss()

    def forward(self, batch_dict):

        for cur_module in self.module_list:
            batch_dict = cur_module(batch_dict)

        if self.training:
            loss, tb_dict, disp_dict, sum_loss, bpp, bce = self.get_training_loss(batch_dict)
            # loss, tb_dict, disp_dict, sum_loss = self.get_training_loss(batch_dict)
            # ret_dict = {
            #     'loss': loss
            # }
            # return loss, tb_dict, disp_dict, sum_loss, bpp, mae, mse_loss
            return loss, tb_dict, disp_dict, sum_loss, bpp, bce
        else:
            pred_dicts, recall_dicts = self.post_processing(batch_dict)
            # points = batch_dict['points']

            # Compute for only front view point bpp
            point_cloud_range = [0, -40, -3, 70.4, 40, 1]
            processed_batches = []
            for batch_id in range(batch_dict['frame_id'].size):
                batch_data = batch_dict['points'][batch_dict['points'][:, 0] == batch_id]
                points = batch_data[:, 1:]
                mask = common_utils.mask_points_by_range(points, point_cloud_range)
                points = points[mask].cpu().numpy()

                batch_ids = np.full((points.shape[0], 1), batch_id, dtype=points.dtype)
                processed_data_with_id = np.concatenate((batch_ids, points), axis=1)
                processed_batches.append(processed_data_with_id)

            points = np.concatenate(processed_batches, axis=0)
            batch_dict['points'] = points
            points = torch.from_numpy(points).to('cuda')

            bpp = self.get_bits(batch_dict['voxels_likelihood']) / float(points.__len__())

            return pred_dicts, recall_dicts, bpp

    def get_bits(self, likelihood):
        bits = -torch.sum(torch.log2(likelihood))

        return bits

    def get_bce(self, data, groud_truth):
        """ Input data and ground_truth are sparse tensor.
        """
        mask = isin(data.C, groud_truth.C)
        bce = criterion(data.F.squeeze(), mask.type(data.F.dtype))
        bce /= torch.log(torch.tensor(2.0)).to(bce.device)
        sum_bce = bce * data.shape[0]

        return sum_bce

    def get_training_loss(self, batch_dict):

        #detection loss
        disp_dict = {}
        loss, tb_dict = self.dense_head.get_loss()

        # bpp loss
        # points = batch_dict['crop_points']
        # bpp = self.get_bits(batch_dict['voxels_likelihood']) / float(points)

        # points = batch_dict['points']

        # Compute for only front view point bpp
        point_cloud_range = [0, -40, -3, 70.4, 40, 1]
        processed_batches = []
        for batch_id in range(batch_dict['frame_id'].size):
            batch_data = batch_dict['points'][batch_dict['points'][:, 0] == batch_id]
            points = batch_data[:, 1:]
            mask = common_utils.mask_points_by_range(points, point_cloud_range)
            points = points[mask].cpu().numpy()

            batch_ids = np.full((points.shape[0], 1), batch_id, dtype=points.dtype)
            processed_data_with_id = np.concatenate((batch_ids, points), axis=1)
            processed_batches.append(processed_data_with_id)

        points = np.concatenate(processed_batches, axis=0)
        temp = float(points.__len__())
        bpp = self.get_bits(batch_dict['voxels_likelihood']) / float(points.__len__())

        # bce loss
        bce, bce_list = 0, []
        for out_cls, ground_truth in zip(batch_dict['out_cls_list'], batch_dict['ground_truth_list']):
            curr_bce = self.get_bce(out_cls, ground_truth) / float(points.__len__())
            bce += curr_bce
            bce_list.append(curr_bce.item())

        lambbda = 0
        alpha = 1
        beta = 1
        # sum_loss = beta * loss
        sum_loss = alpha * bpp + lambbda * bce + beta * loss

        # return loss, tb_dict, disp_dict, sum_loss, bpp, mae, mse_loss
        return loss, tb_dict, disp_dict, sum_loss, bpp, bce
        # return loss, tb_dict, disp_dict, sum_loss


    def post_processing(self, batch_dict):
        post_process_cfg = self.model_cfg.POST_PROCESSING
        batch_size = batch_dict['batch_size']
        final_pred_dict = batch_dict['final_box_dicts']
        recall_dict = {}
        for index in range(batch_size):
            pred_boxes = final_pred_dict[index]['pred_boxes']

            recall_dict = self.generate_recall_record(
                box_preds=pred_boxes,
                recall_dict=recall_dict, batch_index=index, data_dict=batch_dict,
                thresh_list=post_process_cfg.RECALL_THRESH_LIST
            )

        return final_pred_dict, recall_dict
