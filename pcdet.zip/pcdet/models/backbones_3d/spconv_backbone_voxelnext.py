from functools import partial
import torch
import torch.nn as nn
import torch.nn.functional as F

from ...utils.spconv_utils import replace_feature, spconv
from ...autoencoder import Encoder, Decoder, sparse_to_dense, dense_to_sparse
from ...entropy_model import EntropyBottleneck

import MinkowskiEngine as ME
import numpy as np
from ...utils import box_utils, common_utils

import os
os.environ['CUDA_LAUNCH_BLOCKING'] = "1"
os.environ['TORCH_USE_CUDA_DSA'] = "1"


def post_act_block(in_channels, out_channels, kernel_size, indice_key=None, stride=1, padding=0,
                   conv_type='subm', norm_fn=None):

    if conv_type == 'subm':
        conv = spconv.SubMConv3d(in_channels, out_channels, kernel_size, bias=False, indice_key=indice_key)
    elif conv_type == 'spconv':
        conv = spconv.SparseConv3d(in_channels, out_channels, kernel_size, stride=stride, padding=padding,
                                   bias=False, indice_key=indice_key)
    elif conv_type == 'inverseconv':
        conv = spconv.SparseInverseConv3d(in_channels, out_channels, kernel_size, indice_key=indice_key, bias=False)
    else:
        raise NotImplementedError

    m = spconv.SparseSequential(
        conv,
        norm_fn(out_channels),
        nn.ReLU(),
    )

    return m

#####################changecannelsize############################################
class ChannelMapper(nn.Module):
    def __init__(self, in_channels=8, out_channels=32, kernel_size=1, stride=1):
        super(ChannelMapper, self).__init__()
        # 使用 spconv.SubMConv3d 替代 nn.Linear 進行通道映射
        self.sparse_conv = spconv.SubMConv3d(in_channels, out_channels, kernel_size=kernel_size, stride=stride)
        self.relu = nn.ReLU()

    def forward(self, x):
        # 使用 spconv 層進行卷積操作，然後應用激活函數
        x = self.sparse_conv(x)
        x = replace_feature(x, self.relu(x.features))
        return x



class SparseBasicBlock(spconv.SparseModule):
    expansion = 1

    def __init__(self, inplanes, planes, stride=1, norm_fn=None, downsample=None, indice_key=None):
        super(SparseBasicBlock, self).__init__()

        assert norm_fn is not None
        bias = norm_fn is not None
        self.conv1 = spconv.SubMConv3d(
            inplanes, planes, kernel_size=3, stride=stride, padding=1, bias=bias, indice_key=indice_key
        )
        self.bn1 = norm_fn(planes)
        self.relu = nn.ReLU()
        self.conv2 = spconv.SubMConv3d(
            planes, planes, kernel_size=3, stride=stride, padding=1, bias=bias, indice_key=indice_key
        )
        self.bn2 = norm_fn(planes)
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        identity = x

        out = self.conv1(x)
        out = replace_feature(out, self.bn1(out.features))
        out = replace_feature(out, self.relu(out.features))

        out = self.conv2(out)
        out = replace_feature(out, self.bn2(out.features))

        if self.downsample is not None:
            identity = self.downsample(x)

        out = replace_feature(out, out.features + identity.features)
        out = replace_feature(out, self.relu(out.features))

        return out


# class SparseBridgingLayer(nn.Module):
#     def __init__(self):
#         super(SparseBridgingLayer, self).__init__()
#         self.sparse_conv = spconv.SubMConv3d(
#             16, 64, kernel_size=1, stride=1, padding=0, bias=False, indice_key='subm1')
#         self.relu = nn.ReLU()
        # self.linear1 = nn.Linear(64, 128)

    # def forward(self, x, target_size=None):
    #     x = self.sparse_conv(x)
    #     # x = replace_feature(x, self.relu(x.features))
    #     # x = replace_feature(x, self.linear1(x.features))
    #     return x

class VoxelResBackBone8xVoxelNeXt(nn.Module):
    def __init__(self, model_cfg, input_channels, grid_size, **kwargs):
        super().__init__()
        self.model_cfg = model_cfg
        norm_fn = partial(nn.BatchNorm1d, eps=1e-3, momentum=0.01)

        spconv_kernel_sizes = model_cfg.get('SPCONV_KERNEL_SIZES', [3, 3, 3, 3])
        channels = model_cfg.get('CHANNELS', [16, 32, 64, 128, 128])
        # channels = model_cfg.get('CHANNELS', [8, 8, 64, 128, 128])
        out_channel = model_cfg.get('OUT_CHANNEL', 128)

        self.sparse_shape = grid_size[::-1] + [1, 0, 0]
        # self.sparse_shape = [961, 720, 128]

        # self.sparse_bridging_layer = SparseBridgingLayer()


        # 初始化通道映射模組
        # self.channel_mapper = ChannelMapper(in_channels=8, out_channels=32)


        self.conv_input = spconv.SparseSequential(
            spconv.SubMConv3d(3, channels[0], 3, padding=1, bias=False, indice_key='subm1'),
            norm_fn(channels[0]),
            nn.ReLU(),
        )

        block = post_act_block

        self.conv1 = spconv.SparseSequential(
            SparseBasicBlock(channels[0], channels[0], norm_fn=norm_fn, indice_key='res1'),
            SparseBasicBlock(channels[0], channels[0], norm_fn=norm_fn, indice_key='res1'),
        )

        self.conv2 = spconv.SparseSequential(
            # [1600, 1408, 41] <- [800, 704, 21]
            block(channels[0], channels[1], spconv_kernel_sizes[0], norm_fn=norm_fn, stride=2, padding=int(spconv_kernel_sizes[3]//2), indice_key='spconv2', conv_type='spconv'),
            SparseBasicBlock(channels[1], channels[1], norm_fn=norm_fn, indice_key='res2'),
            SparseBasicBlock(channels[1], channels[1], norm_fn=norm_fn, indice_key='res2'),
        )

        self.conv3 = spconv.SparseSequential(
            # [800, 704, 21] <- [400, 352, 11]
            block(channels[1], channels[2], spconv_kernel_sizes[1], norm_fn=norm_fn, stride=2, padding=int(spconv_kernel_sizes[3]//2), indice_key='spconv3', conv_type='spconv'),
            SparseBasicBlock(channels[2], channels[2], norm_fn=norm_fn, indice_key='res3'),
            SparseBasicBlock(channels[2], channels[2], norm_fn=norm_fn, indice_key='res3'),
        )

        self.conv4 = spconv.SparseSequential(
            # [400, 352, 11] <- [200, 176, 6]
            block(channels[2], channels[3], spconv_kernel_sizes[2], norm_fn=norm_fn, stride=2, padding=int(spconv_kernel_sizes[3]//2), indice_key='spconv4', conv_type='spconv'),
            SparseBasicBlock(channels[3], channels[3], norm_fn=norm_fn, indice_key='res4'),
            SparseBasicBlock(channels[3], channels[3], norm_fn=norm_fn, indice_key='res4'),
        )

        self.conv5 = spconv.SparseSequential(
            # [200, 176, 6] <- [100, 88, 3]
            block(channels[3], channels[4], spconv_kernel_sizes[3], norm_fn=norm_fn, stride=2, padding=int(spconv_kernel_sizes[3]//2), indice_key='spconv5', conv_type='spconv'),
            SparseBasicBlock(channels[4], channels[4], norm_fn=norm_fn, indice_key='res5'),
            SparseBasicBlock(channels[4], channels[4], norm_fn=norm_fn, indice_key='res5'),
        )
        
        self.conv6 = spconv.SparseSequential(
            # [200, 176, 6] <- [100, 88, 3]
            block(channels[4], channels[4], spconv_kernel_sizes[3], norm_fn=norm_fn, stride=2, padding=int(spconv_kernel_sizes[3]//2), indice_key='spconv6', conv_type='spconv'),
            SparseBasicBlock(channels[4], channels[4], norm_fn=norm_fn, indice_key='res6'),
            SparseBasicBlock(channels[4], channels[4], norm_fn=norm_fn, indice_key='res6'),
        )
        self.conv_out = spconv.SparseSequential(
            # [200, 150, 5] -> [200, 150, 2]
            spconv.SparseConv2d(channels[3], out_channel, 3, stride=1, padding=1, bias=False, indice_key='spconv_down2'),
            norm_fn(out_channel),
            nn.ReLU(),
        )

        self.shared_conv = spconv.SparseSequential(
            spconv.SubMConv2d(out_channel, out_channel, 3, stride=1, padding=1, bias=True),
            nn.BatchNorm1d(out_channel),
            nn.ReLU(True),
        )

        self.forward_ret_dict = {}
        self.num_point_features = out_channel
        self.backbone_channels = {
            'x_conv1': channels[0],
            'x_conv2': channels[1],
            'x_conv3': channels[2],
            'x_conv4': channels[3]
        }

##############ori
        # self.encoder = Encoder(channels=[1, 16, 32, 64, 32, 16])
        # self.decoder = Decoder(channels=[16, 64, 32, 16])
        # self.entropy_bottleneck = EntropyBottleneck(16)

        self.encoder = Encoder(channels=[1, 16, 32, 64, 32, 8])
        self.decoder = Decoder(channels=[8, 64, 32, 16])
        self.entropy_bottleneck = EntropyBottleneck(8)


    def get_likelihood(self, data, quantize_mode):
        data_F, likelihood = self.entropy_bottleneck(data.F,
                                                     quantize_mode=quantize_mode)
        data_Q = ME.SparseTensor(
            features=data_F,
            coordinate_map_key=data.coordinate_map_key,
            coordinate_manager=data.coordinate_manager,
            device=data.device)

        return data_Q, likelihood

    def bev_out(self, x_conv):
        features_cat = x_conv.features
        indices_cat = x_conv.indices[:, [0, 2, 3]]
        spatial_shape = x_conv.spatial_shape[1:]

        indices_unique, _inv = torch.unique(indices_cat, dim=0, return_inverse=True)
        features_unique = features_cat.new_zeros((indices_unique.shape[0], features_cat.shape[1]))
        features_unique.index_add_(0, _inv, features_cat)

        x_out = spconv.SparseConvTensor(
            features=features_unique,
            indices=indices_unique,
            spatial_shape=spatial_shape,
            batch_size=x_conv.batch_size
        )
        return x_out

    def write_ply_ascii_geo(self, filedir, coords):
        if os.path.exists(filedir): os.system('rm ' + filedir)
        f = open(filedir, 'a+')
        f.writelines(['ply\n', 'format ascii 1.0\n'])
        f.write('element vertex ' + str(coords.shape[0]) + '\n')
        f.writelines(['property float x\n', 'property float y\n', 'property float z\n'])
        f.write('end_header\n')
        # coords = coords.astype('int')
        for p in coords:
            f.writelines([str(p[0]), ' ', str(p[1]), ' ', str(p[2]), '\n'])
        f.close()

        return

    def forward(self, batch_dict):
        """
        Args:
            batch_dict:
                batch_size: int
                vfe_features: (num_voxels, C)
                voxel_coords: (num_voxels, 4), [batch_idx, z_idx, y_idx, x_idx]
        Returns:
            batch_dict:
                encoded_spconv_tensor: sparse tensor
        """
        voxel_features, voxel_coords = batch_dict['voxel_features'], batch_dict['voxel_coords']

# ############可是化###################
#         voxel_c = voxel_coords[:, 1:].cpu().numpy().astype(np.float32)
#         self.write_ply_ascii_geo('/home/user/Desktop/voxel_c_00500501.ply', voxel_c)

        batch_size = batch_dict['batch_size']
        # #####################PCGCV2###############################
        voxel_features = torch.ones((voxel_coords.shape[0], 1), dtype=torch.float32).to(voxel_coords.device)
        #
        x_sp_tensor = spconv.SparseConvTensor(
            features=voxel_features,
            indices=voxel_coords.int(),
            spatial_shape=self.sparse_shape,
            batch_size=batch_size
        )

        # x = self.conv_input(x_sp_tensor)
        # x_conv1 = self.conv1(x)

        # Encoder
        y = ME.SparseTensor(coordinates=x_sp_tensor.indices, features=x_sp_tensor.features)

        y_down, y_list = self.encoder(y)

        ground_truth_list = y_list[1:] + [y]
        nums_list = [[len(C) for C in ground_truth.decomposed_coordinates] \
                     for ground_truth in ground_truth_list]

        # Quantizer & Entropy Model
        y_q, likelihood = self.get_likelihood(y_down,
        quantize_mode="noise" if self.training else "symbols")

        # Decoder
        out_cls_list, y_head = self.decoder(y_q, nums_list, ground_truth_list, self.training)

        batch_dict.update({
            'voxels_input': y,
            'out_cls_list': out_cls_list,
            'voxels_output': y_head,
            'voxels_prior': y_q,
            'voxels_likelihood': likelihood,
            'ground_truth_list': ground_truth_list,
        })

        y_q = spconv.SparseConvTensor(
            features=y_q.F,
            indices=y_q.C.int(),
            spatial_shape=self.sparse_shape,
            batch_size=batch_size
        )

        # 定義線性層並將其移動到 y_q.features 所在的設備
        linear_layer = nn.Linear(in_features=8, out_features=16).to(y_q.features.device)

        # 對 SparseTensor 的 features 進行線性變換
        y_q = y_q.replace_feature(linear_layer(y_q.features))

        # sparse_tensor 現在已經包含新的特徵

        # y_q = self.sparse_bridging_layer(y_q)

        # 通過通道映射模組獲取新的輸出，shape 為 (1000, 32)
        # y_q = self.channel_mapper(y_q)



        # x_conv2 = self.conv2(x_conv1)

        x_conv2 = self.conv2(y_q)
        # x_conv3 = self.conv3(x)
        # x_conv3 = self.conv3(y_q)
        x_conv3 = self.conv3(x_conv2)
        x_conv4 = self.conv4(x_conv3)
        x_conv5 = self.conv5(x_conv4)
        x_conv6 = self.conv6(x_conv5)


        x_conv5.indices[:, 1:] *= 2
        x_conv6.indices[:, 1:] *= 4
        x_conv7 = x_conv4.replace_feature(torch.cat([x_conv4.features, x_conv5.features, x_conv6.features])) ###這行將 x_conv7 的索引設置為 x_conv4、x_conv5 和 x_conv6 的索引的串接。
        x_conv7.indices = torch.cat([x_conv4.indices, x_conv5.indices, x_conv6.indices])  ####這行將 x_conv7 的索引設置為 x_conv4、x_conv5 和 x_conv6 的索引的串接。

        out = self.bev_out(x_conv7)

        out = self.conv_out(out)
        out = self.shared_conv(out)

        batch_dict.update({
            'encoded_spconv_tensor': out,
            'encoded_spconv_tensor_stride': 8
        })
        batch_dict.update({
            'multi_scale_3d_features': {
                # 'x_conv1': x_conv1,
                # 'x_conv2': x_conv2,
                'x_conv3': x_conv3,
                'x_conv4': x_conv4,
            }
        })
        batch_dict.update({
            'multi_scale_3d_strides': {
                'x_conv1': 1,
                'x_conv2': 2,
                'x_conv3': 4,
                'x_conv4': 8,
            }
        })
        
        return batch_dict
