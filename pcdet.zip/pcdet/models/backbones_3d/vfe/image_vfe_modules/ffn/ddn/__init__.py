from .ddn_deeplabv3 import DDNDeepLabV3

__all__ = {
    'DDNDeepLabV3': DDNDeepLabV3
}
